

Upload & Activate WordPress Web Template -> ( ...\neptune-by-osetin\neptune-by-osetin\ )
* If you cannot import, try "Switch to manual import!" -> ( ...\demo-data\manual import\ )
* UserPro license code: 0d9266ab-4233-42ee-b48b-5fc5bfb8ee5f
* UserPro Messaging license code: 07410c19-487f-4b42-a620-244f630599a2
* Upload & Activate "WPBakery / Visual Composer" Nulled Latest Version -> ( ...\Plugins\js_composer_v5.6_nulled.zip )
